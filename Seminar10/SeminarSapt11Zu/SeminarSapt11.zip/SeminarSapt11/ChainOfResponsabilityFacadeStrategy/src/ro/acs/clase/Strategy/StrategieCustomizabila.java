package ro.acs.clase.Strategy;

public class StrategieCustomizabila implements IStrategy{
    @Override
    public TehnicaFiltrare generareStrategie() {
        //Aici se pot citi de la tastaura niste stringuri de tip eseu, note, clasament
        //si sa se construiasca filtrele
        return null;
    }
}
