package ro.acs.clase.Strategy;

public interface IStrategy {
    TehnicaFiltrare generareStrategie();
}
